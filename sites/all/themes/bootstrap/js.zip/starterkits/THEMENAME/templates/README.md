This directory is used to implement various core, contrib, Bootstrap and custom
templates as well as theme and \[pre\]process functions.

Please refer to the [Theme Registry](<!-- @url registry -->) topic for more info.
